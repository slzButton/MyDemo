//
//  Food.h
//  Snake
//
//  Created by MENGCHEN on 2017/1/6.
//  Copyright © 2017年 MENGCHEN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Food : NSObject



@end
