//
//  BroadcastViewController.h
//  ReplayUI
//
//  Created by MENGCHEN on 2017/1/10.
//  Copyright © 2017年 MENGCHEN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ReplayKit/ReplayKit.h>

@interface BroadcastViewController : UIViewController

@end
